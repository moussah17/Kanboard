<?php
namespace Kanboard\Plugin\TimeSpentChart\Controller;
use Kanboard\Controller\BaseController;
class TimeSpentPerUserController extends BaseController
{   
    public function timeSpentByUser()
    {
        $user = $this->getUser();
        $users = $this->userModel->getAll();
        $this->response->html($this->helper->layout->dashboard('TimeSpentChart:dashboard/timeSpentByUser', array(
            'title' => t('Time Spent by User'),
            'users' => $users,
            'user' => $user
        )));
    }
      public function update()
    {
        if ($_POST['selected_user']) {
            $selectedUserId = $_POST['selected_user'];
            $startDate = strtotime($_POST['start_date']);
            $endDate = strtotime($_POST['end_date']);;
            $timeSpentInByDate = $this->subtaskTimeTrackingModel->getTimespentPerUserPerDay($selectedUserId, $startDate, $endDate);
            $timeSpentInHours=0;
            $sameDate=date('Y-m-d');
            $timeSpentThatDate=0;
            if($timeSpentInByDate!=null){
            foreach($timeSpentInByDate as $perday) 
            {
                $timeSpentInHours+=$perday['time_spent'];
                $date=date('Y-m-d',$perday['end']);
                
                if(date("Y-m-d", $perday['end'])!=$sameDate){
                    $sameDate=date("Y-m-d", $perday['end']);
                    $timeSpentThatDate=0;
                }
                $timeSpentThatDate +=$perday['time_spent'];
                $datesArray[$date]=array('timeSpent' =>$timeSpentThatDate ,'title' => $date);
            }
                }else{
                for($singleDate=date("Y-m-d", $startDate);$singleDate<=date("Y-m-d", $endDate);$singleDate++){
                   $datesArray[$singleDate]=array('timeSpent' =>0 ,'title' => $singleDate);            
                }
                }
            $user = $this->getUser();

         $this->response->html($this->helper->layout->dashboard('TimeSpentChart:dashboard/chart-page', array(
            'title' => t('Projects overview for %s', $this->helper->user->getFullname($user)),
            'paginator' => $this->projectPagination->getDashboardPaginator($user['id'], 'projects', 25),
            'user' => $user,
            'dates' => $datesArray,
            'timeSpentInHours' => $timeSpentInHours,
            'start' =>$startDate,
            'end' =>$endDate,
        )));
}
    }
}
?>