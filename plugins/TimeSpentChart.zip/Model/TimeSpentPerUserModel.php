<?php
namespace Kanboard\Plugin\TimeSpentChart\Model;
use DateTime;
use Kanboard\Core\Base;

/**
 * Subtask time tracking
 *
 * @package  Kanboard\Model
 * @author   Frederic Guillot
 */
class TimeSpentPerUserModel extends Base
{
    /**
     * SQL table name
     *
     * @var string
     */
    const TABLE = 'subtask_time_tracking';

  /**
     * Time spent by user between 2 dates
     *
     * @access public
     * @param  integer   $userId    User id
     * @param  integer   $startDate    Start date
     * @param  integer   $endDate    end date
     * @return array
     */
    public function getTimespentPerUser($userId, $startDate, $endDate)
    {
        return $this->db
            ->table(self::TABLE)
            ->eq(self::TABLE.'.user_id', $userId)
            ->gt(self::TABLE.'.start', $startDate)
            ->lt(self::TABLE.'.end', $endDate)
            ->findAll();
    }
}
