<li>
        <?= $this->modal->medium('lock', t('plugin'), 'TimeSpentPerUserController', 'timeSpentByUser') ?>
</li>