<li <?= $this->app->checkMenuSelection('TimeSpentPerUserController', 'timeSpentByUser','TimeSpentChart') ?>>
            <?= $this->url->link(t('Time Spent By User (plugin)'), 'TimeSpentPerUserController', 'timeSpentByUser', array('plugin' => 'TimeSpentChart','user_id' => $user['id'])) ?>
</li>   
